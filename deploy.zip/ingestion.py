"""
Ingestion module for Content Intelligence Platform.

Fetches **globally trending** videos from YouTube Data API v3 using
the `videos.list(chart=mostPopular)` endpoint across curated regions
— eliminating ALL niche-based query bias.

Features:
  - Multi-region trending video ingestion (India excluded)
  - Optional category expansion (Music, Gaming, Tech, etc.)
  - Automatic deduplication (keeps highest-view version)
  - Failsafe retry with exponential back-off
  - Structured return objects (dataclasses)
  - Auto-categorization from YouTube categoryId
  - Stale data cleanup before ingestion
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import get_settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Curated regions — India (IN) excluded to reduce noise/irrelevant content
ALLOWED_REGIONS = ["US", "GB", "CA", "DE", "FR", "AU", "AE"]

# YouTube video category ID → readable label
YOUTUBE_CATEGORY_MAP = {
    "1": "film & animation",
    "2": "autos & vehicles",
    "10": "music",
    "15": "pets & animals",
    "17": "sports",
    "18": "short movies",
    "19": "travel & events",
    "20": "gaming",
    "21": "videoblogging",
    "22": "people & blogs",
    "23": "comedy",
    "24": "entertainment",
    "25": "news & politics",
    "26": "howto & style",
    "27": "education",
    "28": "science & technology",
    "29": "nonprofits & activism",
    "30": "movies",
    "43": "shows",
}

# Max retry attempts for transient YouTube API failures
MAX_RETRY_ATTEMPTS = 3
RETRY_BACKOFF_SECONDS = 2


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------
@dataclass
class RawVideo:
    """Represents a single video as returned by the ingestion layer."""

    video_id: str
    title: str
    channel: str
    description: str
    published_at: str
    thumbnail_url: str
    views: int = 0
    likes: int = 0
    comments: int = 0
    niche: str = ""
    platform: str = "youtube"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# YouTube API client
# ---------------------------------------------------------------------------
class YouTubeClient:
    """
    Thin abstraction over the YouTube Data API v3.

    Handles:
      - Session management with connection pooling
      - Retry with exponential back-off on transient errors
      - Trending video fetching (mostPopular chart) ONLY
    """

    BASE_URL = "https://www.googleapis.com/youtube/v3"

    # Known placeholder values that should not be treated as valid keys
    _PLACEHOLDER_KEYS = frozenset({
        "your_youtube_api_key_here",
        "your_api_key_here",
        "CHANGE_ME",
        "xxx",
        "",
    })

    def __init__(self, api_key: Optional[str] = None) -> None:
        settings = get_settings()
        self._api_key = api_key or settings.youtube_api_key
        if not self._api_key or self._api_key.strip().lower() in self._PLACEHOLDER_KEYS:
            raise ValueError(
                "YouTube API key is missing or still set to a placeholder. "
                "Set a valid YOUTUBE_API_KEY in your .env file. "
                "Get one at https://console.cloud.google.com/apis/credentials"
            )

        # Persistent session with retry strategy
        self._session = self._build_session()

    # ----- Private helpers -------------------------------------------------

    def _build_session(self) -> requests.Session:
        session = requests.Session()
        retry_strategy = Retry(
            total=MAX_RETRY_ATTEMPTS,
            backoff_factor=RETRY_BACKOFF_SECONDS,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session

    def _get(self, endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a GET request with the API key injected."""
        params["key"] = self._api_key
        url = f"{self.BASE_URL}/{endpoint}"
        logger.debug("GET %s?%s", url, urlencode(params))

        response = self._session.get(url, params=params, timeout=15)
        response.raise_for_status()
        return response.json()

    # ----- Fetch trending videos -------------------------------------------

    def fetch_trending(
        self,
        region_code: str = "US",
        max_results: int = 50,
    ) -> List[Dict[str, Any]]:
        """
        Fetch trending (mostPopular) videos for a region.

        Uses the videos.list endpoint with chart=mostPopular which does
        NOT require a search query — returns truly trending content.
        """
        params: Dict[str, Any] = {
            "part": "snippet,statistics,contentDetails",
            "chart": "mostPopular",
            "regionCode": region_code,
            "maxResults": min(max_results, 50),
        }

        # Failsafe retry loop
        for attempt in range(1, MAX_RETRY_ATTEMPTS + 1):
            try:
                data = self._get("videos", params)
                items = data.get("items", [])
                # Tag each item with region for tracking
                for item in items:
                    item["_region"] = region_code
                logger.info(
                    "Trending %s: %d videos fetched.",
                    region_code, len(items),
                )
                return items
            except requests.HTTPError as exc:
                status = getattr(exc.response, "status_code", None)
                if status == 403:
                    logger.warning(
                        "Quota/access error for region=%s: %s",
                        region_code, exc,
                    )
                    return []  # Don't retry on quota errors
                elif attempt < MAX_RETRY_ATTEMPTS:
                    logger.warning(
                        "YouTube API error (region=%s, attempt %d/%d): %s — retrying...",
                        region_code, attempt, MAX_RETRY_ATTEMPTS, exc,
                    )
                    time.sleep(RETRY_BACKOFF_SECONDS * attempt)
                else:
                    logger.error(
                        "YouTube trending API failed after %d attempts (region=%s): %s",
                        MAX_RETRY_ATTEMPTS, region_code, exc,
                    )
            except Exception as exc:
                if attempt < MAX_RETRY_ATTEMPTS:
                    logger.warning(
                        "Unexpected error fetching trending (region=%s, attempt %d/%d): %s — retrying...",
                        region_code, attempt, MAX_RETRY_ATTEMPTS, exc,
                    )
                    time.sleep(RETRY_BACKOFF_SECONDS * attempt)
                else:
                    logger.error(
                        "Trending fetch failed after %d attempts (region=%s): %s",
                        MAX_RETRY_ATTEMPTS, region_code, exc,
                    )

        return []

    # ----- Parse into structured objects -----------------------------------

    @staticmethod
    def parse_video_item(item: Dict[str, Any], category: str = "trending") -> RawVideo:
        """Convert a YouTube API item dict into a ``RawVideo`` dataclass."""
        snippet = item.get("snippet", {})
        stats = item.get("statistics", {})
        thumbnails = snippet.get("thumbnails", {})
        thumb_url = (
            thumbnails.get("high", {}).get("url")
            or thumbnails.get("medium", {}).get("url")
            or thumbnails.get("default", {}).get("url", "")
        )

        return RawVideo(
            video_id=item.get("id", item.get("video_id", "")),
            title=snippet.get("title", ""),
            channel=snippet.get("channelTitle", ""),
            description=snippet.get("description", ""),
            published_at=snippet.get("publishedAt", ""),
            thumbnail_url=thumb_url,
            views=int(stats.get("viewCount", 0)),
            likes=int(stats.get("likeCount", 0)),
            comments=int(stats.get("commentCount", 0)),
            niche=category,
        )


# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------
def _deduplicate_items(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Deduplicate video items by video ID, keeping the version with highest views.
    """
    seen: Dict[str, Dict[str, Any]] = {}
    for item in items:
        vid = item.get("id", "")
        if isinstance(vid, dict):
            vid = vid.get("videoId", "")
        if not vid:
            continue

        views = int(item.get("statistics", {}).get("viewCount", 0))
        if vid not in seen or views > int(seen[vid].get("statistics", {}).get("viewCount", 0)):
            seen[vid] = item

    return list(seen.values())


def _categorize_video(item: Dict[str, Any]) -> str:
    """
    Derive a category label from the video's YouTube categoryId.

    This replaces hardcoded niche queries with auto-detected categories.
    """
    snippet = item.get("snippet", {})
    category_id = snippet.get("categoryId", "")

    if category_id in YOUTUBE_CATEGORY_MAP:
        return YOUTUBE_CATEGORY_MAP[category_id]

    return "trending"


# ---------------------------------------------------------------------------
# Stale data cleanup
# ---------------------------------------------------------------------------
def purge_stale_youtube_videos() -> int:
    """
    Delete YouTube videos older than 7 days to ensure data freshness.

    Returns the number of rows deleted.
    """
    from database import get_connection

    with get_connection() as conn:
        cursor = conn.execute(
            """DELETE FROM videos
               WHERE platform = 'youtube'
                 AND published_at < datetime('now', '-7 days');"""
        )
        deleted = cursor.rowcount

    if deleted > 0:
        logger.info("Purged %d stale YouTube videos (older than 7 days).", deleted)
    else:
        logger.info("No stale YouTube videos to purge.")

    return deleted


# ---------------------------------------------------------------------------
# Public high-level functions
# ---------------------------------------------------------------------------
def ingest_trending_videos(
    regions: Optional[List[str]] = None,
) -> List[RawVideo]:
    """
    Ingest globally trending videos across multiple regions.

    This is the primary ingestion method — no query bias, pure trending data.
    India (IN) is excluded from the default region list.

    Returns a deduplicated list of ``RawVideo`` objects ready for processing.
    """
    regions = regions or ALLOWED_REGIONS

    client = YouTubeClient()
    all_items: List[Dict[str, Any]] = []

    total_calls = len(regions)
    call_count = 0

    for region in regions:
        call_count += 1
        logger.info(
            "▶ Fetching trending [%d/%d] region=%s",
            call_count, total_calls, region,
        )

        items = client.fetch_trending(region_code=region)
        all_items.extend(items)

        # Small delay between calls to respect quota
        if call_count < total_calls:
            time.sleep(0.5)

    print(f"Fetched {len(all_items)} videos")
    logger.info(
        "Total raw items fetched: %d (before dedup) from %d regions.",
        len(all_items), len(regions),
    )

    # Deduplicate
    unique_items = _deduplicate_items(all_items)
    dupes_removed = len(all_items) - len(unique_items)
    print(f"After dedup: {len(unique_items)}")
    logger.info(
        "Deduplication: %d duplicates removed → %d unique videos.",
        dupes_removed, len(unique_items),
    )

    # Parse into RawVideo objects
    videos = []
    for item in unique_items:
        category = _categorize_video(item)
        try:
            video = YouTubeClient.parse_video_item(item, category)
            videos.append(video)
        except Exception as exc:
            logger.warning("Failed to parse video item: %s", exc)

    logger.info("✔ Trending ingestion complete: %d videos.", len(videos))
    return videos


def ingest_videos() -> List[RawVideo]:
    """
    Primary ingestion entry point.

    Uses trending-based ingestion (mostPopular) ONLY.
    No niche-based search — all query bias has been removed.
    """
    return ingest_trending_videos()
