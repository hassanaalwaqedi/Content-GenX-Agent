"""
Pipeline runner for Content Intelligence Platform.

Orchestrates the full ETL flow:
  1. Purge stale YouTube data (freshness guarantee)
  2. Ingest real trending videos from YouTube (mostPopular)
  3. Process, score, and filter
  4. Enrich with AI-derived metadata
  5. Extract transcripts
  6. Store in database (upsert)

Usage:
  python main.py
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from typing import Any, Dict

from config import get_settings
from database import init_db, insert_videos, acquire_pipeline_lock, release_pipeline_lock
from ingestion import ingest_videos, purge_stale_youtube_videos
from reddit_ingestion import ingest_reddit_posts
from processing import process_videos
from ai_enrichment import enrich_videos
from transcripts import fetch_transcript

logger = logging.getLogger(__name__)


def _configure_logging() -> None:
    """Set up structured logging based on config."""
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format=settings.log_format,
        handlers=[logging.StreamHandler(sys.stdout)],
    )
    # Silence noisy third-party loggers
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def run_pipeline(triggered_by: str = "manual") -> Dict[str, Any]:
    """
    Execute the complete data pipeline.

    Args:
        triggered_by: Origin of the run ("manual", "api", "scheduler").

    Returns a summary dict with counts for each stage.
    """
    start = datetime.now(timezone.utc)
    logger.info("=" * 60)
    logger.info("  CONTENT INTELLIGENCE PIPELINE -- START")
    logger.info("  Timestamp: %s", start.isoformat())
    logger.info("  Triggered by: %s", triggered_by)
    logger.info("  Strategy: Global trending (mostPopular, no niche bias)")
    logger.info("=" * 60)

    result: Dict[str, Any] = {
        "started_at": start.isoformat(),
        "ingested": 0,
        "processed": 0,
        "enriched": 0,
        "stored": 0,
        "stale_purged": 0,
        "status": "unknown",
    }

    # Acquire database-level pipeline lock
    run_id: int | None = None
    try:
        # ---- Step 0: Initialize database ------------------------------------
        logger.info("Step 0/6 -- Initializing database...")
        init_db()

        run_id = acquire_pipeline_lock(triggered_by=triggered_by)

        # ---- Step 1: Preflight check ----------------------------------------
        logger.info("Step 1/6 -- Preflight checks...")
        settings = get_settings()
        yt_key = settings.youtube_api_key
        if not yt_key or yt_key.strip().lower() in (
            "your_youtube_api_key_here", "your_api_key_here", "change_me", "xxx", ""
        ):
            logger.error(
                "YouTube API key is missing or set to a placeholder! "
                "Set a valid YOUTUBE_API_KEY in .env"
            )
            result["status"] = "failed"
            result["error"] = (
                "YouTube API key not configured. "
                "Set YOUTUBE_API_KEY in your .env file."
            )
            return result

        # ---- Step 2: Ingest -------------------------------------------------
        logger.info("Step 2/6 -- Ingesting trending videos globally + Reddit...")
        raw_videos = ingest_videos()  # Uses mostPopular trending ONLY
        logger.info("YouTube trending: %d videos ingested.", len(raw_videos))

        reddit_posts = ingest_reddit_posts()
        logger.info("Reddit: %d posts ingested.", len(reddit_posts))

        raw_videos.extend(reddit_posts)
        result["ingested"] = len(raw_videos)
        logger.info("Total ingestion: %d items (YouTube + Reddit).", len(raw_videos))

        if not raw_videos:
            logger.warning("No content ingested -- check API keys.")
            result["status"] = "completed_empty"
            result["error"] = "Zero items ingested -- check YouTube/Reddit API keys."
            return result

        # ---- Step 2b: Purge stale data (AFTER successful ingestion) ---------
        # Only purge old data once we've confirmed new data is available.
        # This prevents the "purge everything → fail to ingest → empty DB" scenario.
        logger.info("Step 2b/6 -- Purging stale YouTube data (>7 days)...")
        stale_count = purge_stale_youtube_videos()
        result["stale_purged"] = stale_count
        logger.info("Purged %d stale records.", stale_count)

        # ---- Step 3: Process ------------------------------------------------
        logger.info("Step 3/6 -- Processing and scoring...")
        processed = process_videos(raw_videos)
        result["processed"] = len(processed)
        logger.info("Processing complete: %d videos passed filters.", len(processed))

        if not processed:
            logger.warning("All videos filtered out -- nothing to store.")
            result["status"] = "completed_filtered"
            return result

        # ---- Step 4: AI Enrichment ------------------------------------------
        logger.info("Step 4/6 -- Enriching with AI metadata...")
        enriched = enrich_videos(processed)
        result["enriched"] = len(enriched)
        logger.info("Enrichment complete: %d videos enriched.", len(enriched))

        # ---- Step 5: Transcript Extraction ----------------------------------
        logger.info("Step 5/6 -- Extracting transcripts (YouTube only)...")
        transcript_count = 0
        for idx, video in enumerate(enriched):
            vid_id = video.get("video_id", "")
            if vid_id and not vid_id.startswith("reddit_"):
                transcript = fetch_transcript(vid_id)
                if transcript:
                    video["transcript"] = transcript
                    transcript_count += 1
                # Throttle to avoid YouTube IP blocking
                if idx < len(enriched) - 1:
                    import time
                    time.sleep(1.0)
        result["transcripts"] = transcript_count
        logger.info("Transcripts extracted: %d/%d videos.", transcript_count, len(enriched))

        # ---- Step 6: Store --------------------------------------------------
        logger.info("Step 6/6 -- Storing in database (upsert)...")
        stored = insert_videos(enriched)
        result["stored"] = stored
        logger.info("Storage complete: %d videos upserted.", stored)

        result["status"] = "completed"

    except Exception as exc:
        logger.error("Pipeline FAILED: %s", exc, exc_info=True)
        result["status"] = "failed"
        result["error"] = str(exc)

    finally:
        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        result["elapsed_seconds"] = round(elapsed, 2)
        result["finished_at"] = datetime.now(timezone.utc).isoformat()

        # Release database-level pipeline lock
        if run_id is not None:
            try:
                release_pipeline_lock(run_id, result)
            except Exception as lock_exc:
                logger.error("Failed to release pipeline lock: %s", lock_exc)

        logger.info("=" * 60)
        logger.info("  PIPELINE COMPLETE -- %s", result["status"].upper())
        logger.info(
            "  Purged=%d  Ingested=%d  Processed=%d  Enriched=%d  Stored=%d",
            result.get("stale_purged", 0),
            result["ingested"],
            result["processed"],
            result["enriched"],
            result["stored"],
        )
        logger.info("  Elapsed: %.2fs", elapsed)
        logger.info("=" * 60)

    return result


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
def main() -> None:
    """CLI entry point."""
    _configure_logging()
    settings = get_settings()

    logger.info("Content Intelligence Platform v1.1.0")
    logger.info("Strategy: Global trending ingestion (mostPopular, NO niche bias)")
    logger.info("Regions: %s", ", ".join(["US", "GB", "CA", "DE", "FR", "AU", "AE"]))
    logger.info("Database: %s", settings.sqlite_db_path)

    result = run_pipeline()
    sys.exit(0 if result["status"].startswith("completed") else 1)


if __name__ == "__main__":
    main()
