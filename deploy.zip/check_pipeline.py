import time
import requests

print("Waiting 90 seconds for pipeline to complete...")
time.sleep(90)

h = requests.get('https://d3tcfetguww88w.cloudfront.net/health', timeout=10).json()
p = requests.get('https://d3tcfetguww88w.cloudfront.net/pipeline/history', timeout=10).json()

print(f"Total videos: {h['total_videos']}")
print(f"Niches: {h['niches']}")
print(f"Database: {h['database']}")
print()
run = p['runs'][0]
print(f"Latest run status: {run['status']}")
print(f"  Ingested: {run['videos_ingested']}")
print(f"  Processed: {run['videos_processed']}")
print(f"  Enriched: {run['videos_enriched']}")
print(f"  Stored: {run['videos_stored']}")
if run.get('error_message'):
    print(f"  Error: {run['error_message']}")
